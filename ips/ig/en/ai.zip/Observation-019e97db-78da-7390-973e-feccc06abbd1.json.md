#  - International Patient Summary for Mikael Rinnetmäki v0.4.0

## : 

[Raw json](Observation-019e97db-78da-7390-973e-feccc06abbd1.json) | [Download](Observation-019e97db-78da-7390-973e-feccc06abbd1.json)

