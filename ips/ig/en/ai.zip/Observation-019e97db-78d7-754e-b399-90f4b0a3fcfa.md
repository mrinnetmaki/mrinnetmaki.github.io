#  - International Patient Summary for Mikael Rinnetmäki v0.4.0

## : 

Profiles: [IPA-Observation](http://hl7.org/fhir/uv/ipa/STU1.1/StructureDefinition-ipa-observation.html) version: 1.1.0, [Observation Results - Laboratory/Pathology (IPS)](http://hl7.org/fhir/uv/ips/STU2/StructureDefinition-Observation-results-laboratory-pathology-uv-ips.html), [Observation: Medical Test Result (EU core)](http://hl7.eu/fhir/base/2.0.0/StructureDefinition-medicalTestResult-eu-core.html)

Security Labels: [device reported (Details: ObservationValue code DEVRPT = 'device reported')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ObservationValue.html), [patient reported (Details: ObservationValue code PATRPT = 'patient reported')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ObservationValue.html), [syntactic transform (Details: ObservationValue code SYNTAC = 'syntactic transform')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ObservationValue.html), [mapped (Details: ObservationValue code MAPPED = 'mapped')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ObservationValue.html), [patient asserted (Details: ObservationValue code PATAST = 'patient asserted')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ObservationValue.html), [Artificial Intelligence asserted (Details: ObservationValue code AIAST = 'Artificial Intelligence asserted')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ObservationValue.html)

**status**: Final

**category**: Laboratory

**code**: B -Trom (trombosyytit)

**subject**: [Mikael Rinnetmäki](Bundle-IpsBundle.md#urn-uuid-b4ac89c5-6589-417f-beef-d3fb1ef9c70f)

**effective**: 2026-05-22 14:40:00+0200

**performer**: Fimlab

**value**: 191 x10E9/l (Details: UCUM code/nL = '/nL')

**interpretation**: Normal

### ReferenceRanges

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Low** | **High** | **Text** |
| * | 150 | 360 | 150-360x10E9/l |

