# Consent-data-use-healthcare - International Patient Summary for Mikael Rinnetmäki v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Consent-data-use-healthcare**

## Example Consent: Consent-data-use-healthcare

I want my data to be used for my treatment. Please use it! I'm fine with AI and decision support systems having access to my data for this purpose



## Resource Content

```json
{
  "resourceType" : "Consent",
  "id" : "0b8b4bfe-12e8-4dcc-9299-27fd76e464ce",
  "meta" : {
    "profile" : ["http://hl7.eu/fhir/eps/StructureDefinition/consent-eu-eps"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "PATRPT",
      "display" : "patient reported"
    }]
  },
  "status" : "active",
  "scope" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
      "code" : "adr",
      "display" : "Advanced Care Directive"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
      "code" : "patient-privacy",
      "display" : "Privacy Consent"
    }],
    "text" : "Patient Privacy"
  },
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/consentcategorycodes",
      "code" : "npp",
      "display" : "Notice of Privacy Practices"
    },
    {
      "system" : "http://loinc.org",
      "code" : "59284-0",
      "display" : "Patient Consent"
    },
    {
      "system" : "http://loinc.org",
      "code" : "64292-6",
      "display" : "Release of information consent Document"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "ICOL",
      "display" : "information collection"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "IDSCL",
      "display" : "information disclosure"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "INFA",
      "display" : "information access"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "IRDSCL",
      "display" : "information redisclosure"
    }],
    "text" : "Release of information consent Document"
  },
  {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/consentcategorycodes",
      "code" : "acd",
      "display" : "Advance Directive"
    }],
    "text" : "Advance Directive"
  }],
  "patient" : {
    "reference" : "urn:uuid:b4ac89c5-6589-417f-beef-d3fb1ef9c70f",
    "display" : "Mikael Rinnetmäki"
  },
  "dateTime" : "2026-02-13T17:59:00+02:00",
  "performer" : [{
    "reference" : "urn:uuid:b4ac89c5-6589-417f-beef-d3fb1ef9c70f",
    "display" : "Mikael Rinnetmäki, the patient"
  }],
  "policy" : [{
    "uri" : "https://eur-lex.europa.eu/eli/reg/2016/679/oj"
  }],
  "provision" : {
    "type" : "permit",
    "action" : [{
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/consentaction",
        "code" : "collect",
        "display" : "Collect"
      }]
    },
    {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/consentaction",
        "code" : "access",
        "display" : "Access"
      }]
    },
    {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/consentaction",
        "code" : "use",
        "display" : "Use"
      }]
    },
    {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/consentaction",
        "code" : "disclose",
        "display" : "Disclose"
      }]
    },
    {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/consentaction",
        "code" : "correct",
        "display" : "Access and Correct"
      }]
    }],
    "purpose" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "TREAT",
      "display" : "treatment"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "COC",
      "display" : "coordination of care"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "ETREAT",
      "display" : "Emergency Treatment"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "BTG",
      "display" : "break the glass"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "ERTREAT",
      "display" : "emergency room treatment"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "HOPERAT",
      "display" : "healthcare operations"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "TREATDS",
      "display" : "decision support assisted treatment decision"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "HTEST",
      "display" : "test health data"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "code" : "PATRQT",
      "display" : "patient requested"
    }]
  }
}

```
