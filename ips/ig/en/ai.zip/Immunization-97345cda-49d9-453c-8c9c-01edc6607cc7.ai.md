# ImmunizationHepatitisA2 - International Patient Summary for Mikael Rinnetmäki v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ImmunizationHepatitisA2**

## Example Immunization: ImmunizationHepatitisA2

Profiles: [IPA-Immunization](http://hl7.org/fhir/uv/ipa/STU1.1/StructureDefinition-ipa-immunization.html) version: 1.1.0, [Immunization (IPS)](http://hl7.org/fhir/uv/ips/STU2/StructureDefinition-Immunization-uv-ips.html), [Immunization (EU core)](http://hl7.eu/fhir/base/2.0.0/StructureDefinition-immunization-eu-core.html), [Immunization - Obligations (EPS)](https://build.fhir.org/ig/hl7-eu/eps/StructureDefinition-immunization-obl-eu-eps.html)

Security Labels: [device reported (Details: v3 Code System ObservationValue code DEVRPT = 'device reported')](http://hl7.org/fhir/R4/v3/ObservationValue/cs.html), [patient reported (Details: v3 Code System ObservationValue code PATRPT = 'patient reported')](http://hl7.org/fhir/R4/v3/ObservationValue/cs.html), [syntactic transform (Details: v3 Code System ObservationValue code SYNTAC = 'syntactic transform')](http://hl7.org/fhir/R4/v3/ObservationValue/cs.html), [mapped (Details: v3 Code System ObservationValue code MAPPED = 'mapped')](http://hl7.org/fhir/R4/v3/ObservationValue/cs.html), [patient asserted (Details: v3 Code System ObservationValue code PATAST = 'patient asserted')](http://hl7.org/fhir/R4/v3/ObservationValue/cs.html)

**status**: Completed

**vaccineCode**: Havrix for hepatitis A

**patient**: [Mikael Rinnetmäki](Bundle-IpsBundle.md#urn-uuid-b4ac89c5-6589-417f-beef-d3fb1ef9c70f)

**occurrence**: 2005-11-18

**manufacturer**: GlaxoSmithCline (GSK)

**doseQuantity**: 1 ml (Details: UCUM codeml = 'ml')

**reasonCode**: Travel vaccinations, Elective immunization for international travel

### ProtocolApplieds

| | | | |
| :--- | :--- | :--- | :--- |
| - | **TargetDisease** | **DoseNumber[x]** | **SeriesDoses[x]** |
| * | Hepatitis A | 2 | 2 |



## Resource Content

```json
{
  "resourceType" : "Immunization",
  "id" : "97345cda-49d9-453c-8c9c-01edc6607cc7",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/ipa/StructureDefinition/ipa-immunization|1.1.0",
    "http://hl7.org/fhir/uv/ips/StructureDefinition/Immunization-uv-ips",
    "http://hl7.eu/fhir/base/StructureDefinition/immunization-eu-core",
    "http://hl7.eu/fhir/eps/StructureDefinition/immunization-obl-eu-eps"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "DEVRPT",
      "display" : "device reported"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "PATRPT",
      "display" : "patient reported"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "SYNTAC",
      "display" : "syntactic transform"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "MAPPED",
      "display" : "mapped"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "PATAST",
      "display" : "patient asserted"
    }]
  },
  "status" : "completed",
  "vaccineCode" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "871751006",
      "display" : "Hepatitis A vaccine"
    },
    {
      "system" : "http://www.whocc.no/atc",
      "code" : "J07BC02",
      "display" : "hepatitis A, inactivated, whole virus"
    },
    {
      "system" : "urn:oid:1.2.246.537.6.610",
      "code" : "50",
      "display" : "Hepatiitti A -rokote"
    },
    {
      "system" : "urn:oid:1.2.246.537.6.611",
      "code" : "13",
      "display" : "Havrix"
    }],
    "text" : "Havrix for hepatitis A"
  },
  "patient" : {
    "reference" : "urn:uuid:b4ac89c5-6589-417f-beef-d3fb1ef9c70f",
    "display" : "Mikael Rinnetmäki"
  },
  "occurrenceDateTime" : "2005-11-18",
  "manufacturer" : {
    "display" : "GlaxoSmithCline (GSK)"
  },
  "doseQuantity" : {
    "value" : 1,
    "unit" : "ml",
    "system" : "http://unitsofmeasure.org",
    "code" : "ml"
  },
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "281657000",
      "display" : "Travel vaccinations"
    }]
  },
  {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "14747002",
      "display" : "Elective immunization for international travel"
    }]
  }],
  "protocolApplied" : [{
    "targetDisease" : [{
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "40468003",
        "display" : "Viral hepatitis, type A"
      },
      {
        "system" : "http://hl7.org/fhir/sid/icd-10",
        "code" : "B15",
        "display" : "Acute hepatitis A"
      },
      {
        "system" : "urn:oid:1.2.246.537.6.609",
        "code" : "13",
        "display" : "Hepatiitti A -viruksen aiheuttama maksatulehdus"
      }],
      "text" : "Hepatitis A"
    }],
    "doseNumberPositiveInt" : 2,
    "seriesDosesPositiveInt" : 2
  }]
}

```
