#  - International Patient Summary for Mikael Rinnetmäki v0.4.0

## : 

[Raw json](Observation-019e967a-597f-779c-899c-2996efd7fbd0.json) | [Download](Observation-019e967a-597f-779c-899c-2996efd7fbd0.json)

